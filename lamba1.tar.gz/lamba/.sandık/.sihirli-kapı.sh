key=$(md5sum exit.txt | awk '{print $1}')
if [ "$key" == "5a85c0ed87c77c3e0f3ef709d79df176" ] || [ "$key" == "e215c4de48970b44ecc978860d1e198a" ]; then
echo "Kapıya sihirli numaraları fısıldadın ve kapı açıldı!"
echo "savolla'nın lanetli lambasından kurtuldun ve etrafında"
echo "onlarca altın sandığı belirdi!"
else
echo "Kapıyı iyice zorladın ancak açılmadı.. Geri dönüp tekrar denemelisin"
fi


